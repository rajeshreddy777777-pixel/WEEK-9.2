import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCInsertDemo {
    // Update these values for your local MySQL setup.
    private static final String JDBC_URL =
            "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        String createTableSQL =
                "CREATE TABLE IF NOT EXISTS users ("
                + "id INT PRIMARY KEY AUTO_INCREMENT, "
                + "name VARCHAR(100) NOT NULL, "
                + "email VARCHAR(255) NOT NULL UNIQUE"
                + ")";

        String insertSQL =
                "INSERT INTO users (name, email) VALUES (?, ?)";

        try (Connection connection =
                     DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement()) {

            statement.executeUpdate(createTableSQL);

            try (PreparedStatement preparedStatement =
                         connection.prepareStatement(insertSQL)) {
                preparedStatement.setString(1, "John Doe");
                preparedStatement.setString(2, "john.doe@example.com");
                preparedStatement.executeUpdate();

                preparedStatement.setString(1, "Jane Doe");
                preparedStatement.setString(2, "jane.doe@example.com");
                preparedStatement.executeUpdate();
            }

            System.out.println("Data inserted successfully.");

        } catch (SQLException e) {
            System.err.println("Database operation failed: " + e.getMessage());
        }
    }
}
