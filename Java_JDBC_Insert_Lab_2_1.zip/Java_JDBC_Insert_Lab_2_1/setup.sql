CREATE DATABASE IF NOT EXISTS mydatabase;
USE mydatabase;

-- The Java program creates this table if it does not already exist.
-- This SQL is optional if the database itself already exists.
