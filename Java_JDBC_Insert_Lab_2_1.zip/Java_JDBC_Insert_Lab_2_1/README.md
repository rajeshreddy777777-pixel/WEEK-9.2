# OOPS Through Java Lab 2.1 — Insert Data Using JDBC

## AIM
Connect to MySQL using JDBC, create the `users` table if it does not exist, and insert two records using `PreparedStatement`.

## Files
- `JDBCInsertDemo.java` — Java program
- `setup.sql` — optional database creation script

## Before running
1. Start MySQL Server.
2. Run `setup.sql` to create `mydatabase` if needed.
3. Update `USERNAME` and `PASSWORD` in `JDBCInsertDemo.java`.
4. Add MySQL Connector/J to the Java project's classpath/dependencies.

## Compile and run
Replace `/path/to/mysql-connector-j.jar` with the actual path to the JDBC driver JAR.

macOS/Linux:
```bash
javac -cp .:/path/to/mysql-connector-j.jar JDBCInsertDemo.java
java -cp .:/path/to/mysql-connector-j.jar JDBCInsertDemo
```

Windows:
```bat
javac -cp .;C:\path\to\mysql-connector-j.jar JDBCInsertDemo.java
java -cp .;C:\path\to\mysql-connector-j.jar JDBCInsertDemo
```

## Expected output
```text
Data inserted successfully.
```

The program inserts John Doe and Jane Doe. Their email addresses are unique; if you run the program again, the unique constraint may reject duplicate email values and an SQL error will be displayed.

## Algorithm
1. Import JDBC classes.
2. Define the JDBC URL, username, and password.
3. Connect to the `mydatabase` database.
4. Execute `CREATE TABLE IF NOT EXISTS users`.
5. Prepare an INSERT statement with placeholders.
6. Bind each user's name and email with `setString()` and execute the insert.
7. Print the success message and handle any `SQLException`.
8. Use try-with-resources to close JDBC resources automatically.
